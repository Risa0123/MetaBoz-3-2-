// pages/index.js

import { useEffect, useState } from 'react';

const Home = () => {
    // ステート：HealthKitから取得した歩数データ
    const [stepCount, setStepCount] = useState(null);

    useEffect(() => {
        // HealthKitデータを取得するためのAPIエンドポイント
        const healthApiEndpoint = '/api/receive-health-data';

        // APIエンドポイントからデータを取得
        fetch(healthApiEndpoint)
            .then(response => response.json())
            .then(data => {
                // レスポンスから歩数データを取得し、ステートに保存
                const { quantity } = data;
                setStepCount(quantity);
            })
            .catch(error => console.error('データの取得エラー:', error));
    }, []);

    return (
        <div>
            <h1>歩数データ</h1>
            {stepCount !== null ? (
                <p>歩数: {stepCount}</p>
            ) : (
                <p>データを取得中...</p>
            )}
        </div>
    );
};

export default Home;
