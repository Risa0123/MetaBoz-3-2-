# app.py

from flask import Flask, request, jsonify

app = Flask(__name__)

# サーバーにPOSTされたHealthKitデータを受け取るAPIエンドポイント
@app.route('/api/receive-health-data', methods=['POST'])
def receive_health_data():
    # POSTされたJSONデータを取得
    data = request.json
    if 'quantity' in data:
        # JSONデータから歩数データを取得
        quantity = data['quantity']
        print(f"Received health data: {quantity}")
        return {'message': 'Data received successfully'}
    else:
        return {'error': 'Invalid data format'}

if __name__ == '__main__':
    app.run(debug=True)
