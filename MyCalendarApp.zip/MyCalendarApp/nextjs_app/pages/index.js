// Next.jsアプリケーションのメインのページ

import React, { useState } from 'react';

const Home = () => {
  const [calendarEvents, setCalendarEvents] = useState([]);

  const fetchCalendarEvents = async () => {
    try {
      // Flaskサーバーにリクエストを送信
      const response = await fetch('http://localhost:5000/calendar-events');
      const data = await response.json();

      // レスポンスのデータをセット
      setCalendarEvents(data);
    } catch (error) {
      console.error('Error fetching calendar events:', error);
    }
  };

  return (
    <div>
      <h1>Calendar Events</h1>
      <button onClick={fetchCalendarEvents}>Fetch Calendar Events</button>
      <ul>
        {calendarEvents.map((event) => (
          <li key={event.id}>{event.summary}</li>
        ))}
      </ul>
    </div>
  );
};

export default Home;
