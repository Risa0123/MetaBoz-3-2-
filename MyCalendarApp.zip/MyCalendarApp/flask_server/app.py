# Flaskアプリケーション

from flask import Flask, jsonify
from googleapiclient.discovery import build

app = Flask(__name__)

# Google Calendar APIのAPIキー
api_key = 'aaaaa'# ここは伏せています！

# Google Calendar APIのビルド
service = build('calendar', 'v3', developerKey=api_key)

@app.route('/calendar-events')
def get_calendar_events():
    try:
        # Googleカレンダーからイベントを取得
        calendar_id = 'primary'  # ここは伏せています！
        events = service.events().list(calendarId=calendar_id).execute()

        # 必要なデータを抽出して返す
        calendar_events = [
            {'id': event['id'], 'summary': event['summary']} for event in events.get('items', [])
        ]

        return jsonify(calendar_events)
    except Exception as e:
        print('Error fetching calendar events:', str(e))
        return jsonify({'error': 'Failed to fetch calendar events'}), 500

if __name__ == '__main__':
    app.run(debug=True)
